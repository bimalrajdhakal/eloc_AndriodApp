package com.nexogen.routefinder.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.nexogen.routefinder.R;

/**
 * Created by nexogen on 7/12/17.
 */

public class CurrentLocationFragment extends Fragment {

    private View view;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.current_location_layout, container, false);


        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

    }
//    MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.map);
//
//        mapFragment.getMapAsync(getActivity());
//
//    //  map.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
//
//    locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
//
//        if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//        // TODO: Consider calling
//        //    ActivityCompat#requestPermissions
//        // here to request the missing permissions, and then overriding
//        //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//        //                                          int[] grantResults)
//        // to handle the case where the user grants the permission. See the documentation
//        // for ActivityCompat#requestPermissions for more details.
//        return;
//    }
//        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1, 1, this);
//}
//
//    @Override
//    public void onMapReady(GoogleMap googleMap) {
//        map = googleMap;
//
//
//        // map.setMyLocationEnabled(true);
//
//
//    }
//
//    @Override
//    public void onLocationChanged(Location location) {
//
//        map.clear();
//        LatLng currentLocation = new LatLng(location.getLatitude(), location.getLongitude());
//
//
//        MarkerOptions markerOptions = new MarkerOptions();
//        markerOptions.position(currentLocation);
//        markerOptions.title("i'm here");
//
//        map.addMarker(markerOptions);
//
//        // map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 17.0f));
//
//        map.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 17.0f));
//    }
//
//    @Override
//    public void onStatusChanged(String provider, int status, Bundle extras) {
//
//    }
//
//    @Override
//    public void onProviderEnabled(String provider) {
//
//    }
//
//    @Override
//    public void onProviderDisabled(String provider) {
//
//    }
//}
//
//
//    }
}
