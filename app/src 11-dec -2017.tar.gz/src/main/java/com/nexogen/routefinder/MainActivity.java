package com.nexogen.routefinder;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.nexogen.routefinder.fragments.CurrentLocationFragment;
import com.nexogen.routefinder.fragments.NavigatorFragment;
import com.nexogen.routefinder.intefaces.FragmentMessangers;
import com.nexogen.routefinder.utils.NavigationDrawerHelper;

public class MainActivity extends AppCompatActivity implements FragmentMessangers, ListView.OnItemClickListener {
    public static NavigationDrawerHelper mNavigationDrawerHelper;
    public FragmentTransaction fragmentTransaction;

    private android.support.v4.app.FragmentManager fragmentManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mNavigationDrawerHelper = new NavigationDrawerHelper();
        mNavigationDrawerHelper.init(this, this);

        ImageButton imageButton = (ImageButton) findViewById(R.id.drwaer_btn);

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mNavigationDrawerHelper.handleSelectOpen(1);
            }
        });
        changeFragment(new CurrentLocationFragment(), null, "HomeFragment", true);

    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        mNavigationDrawerHelper.handleSelect(position);
        switch (position) {
            case 4:
                Toast.makeText(this, "navigator", Toast.LENGTH_SHORT).show();
//                changeFragment(new NavigatorFragment(), null, "NavigatorFragment", true);
                startActivity(new Intent(getApplicationContext(), NavigatorActivity.class));

                break;
            case 5:
                Toast.makeText(this, "addres", Toast.LENGTH_SHORT).show();
                break;
            case 6:
                Toast.makeText(this, "history", Toast.LENGTH_SHORT).show();
                break;
        }

    }


    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        mNavigationDrawerHelper.syncState();
    }

    // We delegate the call to the NavigationDrawerHelper
    // so the actionBar menu item become disabled/enabled depending
    // if the Drawer is opened or not
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        mNavigationDrawerHelper.handleOnPrepareOptionMenu(menu);
        return super.onPrepareOptionsMenu(menu);
    }

    // If any configuration change, the NavigationDrawerHelper
    // will be laying up the ActionBAr
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        mNavigationDrawerHelper.syncState();
        super.onConfigurationChanged(newConfig);
    }


    @Override
    public void changeFragment(Fragment fragment, Bundle data, String fragmentTag, boolean addToBackStack) {
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, fragment, fragmentTag);
        if (data != null)
            fragment.setArguments(data);
        fragmentTransaction.addToBackStack(fragmentTag);
        fragmentTransaction.commit();

    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();

        if (fragmentManager.getBackStackEntryCount() == 0) {
            finish();
        } else {

        }
    }

}

