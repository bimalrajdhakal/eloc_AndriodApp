package com.nexogen.routefinder.intefaces;



public interface TagName {
    String MOBILE_PATTERN = "[0-9]{10}";

    String VALID_EMAIL = "please enter a valid email address";
    String PASSWORD_ST = "please enter the password";
    String MOBILE = "please enter the mobile number";
    String VALID_MOBILE = "Please enter valid 10 digit mobile number";
}
