package com.nexogen.routefinder;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.view.View;

import com.nexogen.routefinder.utils.*;

/**
 * Created by nexogen on 7/12/17.
 */

public class LauncherActivty extends AppCompatActivity implements View.OnClickListener {

    private AppCompatButton btnShare, btnMore, btnFeedback, btnLike, btnContinue;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actvity_launcher);


        init();


    }

    private void init() {

        btnShare = findViewById(R.id.btn_share);
        btnMore = findViewById(R.id.btn_more);
        btnFeedback = findViewById(R.id.btn_feedback);
        btnLike = findViewById(R.id.btn_like);
        btnContinue = findViewById(R.id.btn_continue);

        btnShare.setOnClickListener(this);
        btnMore.setOnClickListener(this);
        btnLike.setOnClickListener(this);
        btnFeedback.setOnClickListener(this);
        btnContinue.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_continue:
                startActivity(new Intent(LauncherActivty.this, com.nexogen.routefinder.utils.MainActivity.class));
                break;
            case R.id.btn_more:
                break;
            case R.id.btn_feedback:
                break;
            case R.id.btn_like:
                break;
            case R.id.btn_share:
                break;
        }
    }
}
