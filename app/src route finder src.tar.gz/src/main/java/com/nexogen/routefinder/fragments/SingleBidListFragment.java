//package com.nexogen.routefinder.fragments;
//
//import android.content.Context;
//import android.os.Build;
//import android.os.Bundle;
//import android.support.annotation.RequiresApi;
//import android.support.v4.app.Fragment;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.AdapterView;
//import android.widget.BaseAdapter;
//import android.widget.CheckBox;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.ListView;
//import android.widget.TextView;
//
//
//import com.nexogen.routefinder.R;
//
//import java.util.ArrayList;
//import java.util.List;
///**
// * A simple {@link Fragment} subclass.
// */
//public class SingleBidListFragment extends Fragment {
//
//    private ListView listView;
//    private List<LocationHistoryModel> locationHistoryModels = new ArrayList<>();
//    private CustomAdapter adapter;
//    private LinearLayout linearLayout;
//    private ArrayList<LocationHistoryModel> checkList = new ArrayList<>();
//
//    public SingleBidListFragment() {
//        // Required empty public constructor
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//
//        // Inflate the layout for this fragment
//        View v = inflater.inflate(R.layout.fragment_single_bid, container, false);
//
//        // linearLayout = (LinearLayout)v.findViewById(R.id.linear_list_expand) ;
//        listView = (ListView)v.findViewById(R.id.listview);
//
//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//
//                final CheckBox checkBox1 = (CheckBox)view.findViewById(R.id.img_circle_listview);
//
//                Log.e(".....................", "onItemClick: " );
//                if (checkBox1.isChecked()) {
//                    checkBox1.setChecked(false);
//                    checkBox1.setButtonDrawable(R.drawable.unchecked);
//
//                    checkList.remove((LocationHistoryModel) checkBox1.getTag());
//                    Log.e("...remove...", "onItemClick: "+(LocationHistoryModel)checkBox1.getTag() );
//                } else {
//
//                    checkBox1.setChecked(true);
//                    checkBox1.setButtonDrawable(R.drawable.checked);
//
//                    checkList.add((LocationHistoryModel) checkBox1.getTag());
//                    Log.e("...add...", "onItemClick: "+(LocationHistoryModel) checkBox1.getTag() );
//                }
//            }
//        });
//
//        for(int i = 0; i< locationHistoryModels.size(); i++){
//
//            locationHistoryModels.add(new LocationHistoryModel(IEXBiddingActivity.arrStr[i]));
//        }
//
//        if(adapter == null){
//
//            adapter = new CustomAdapter(getContext() , locationHistoryModels);
//        }
//        listView.setAdapter(adapter);
//
//        return  v;
//    }
//
//    private class CustomAdapter extends BaseAdapter {
//
//        Context context;
//        List<LocationHistoryModel> biddingLists;
//        // private int[] colors = new int[]{getResources().getColor(R.color.item_odd), getResources().getColor(R.color.item_even)};
//
//        public CustomAdapter(Context context, List<LocationHistoryModel> farmerLists) {
//
//            this.context = context;
//            this.biddingLists = farmerLists;
//
//        }
//
//        @Override
//        public int getCount() {
//            return biddingLists.size();
//        }
//
//        @Override
//        public Object getItem(int position) {
//            return biddingLists.get(position);
//        }
//
//        @Override
//        public long getItemId(int position) {
//            return biddingLists.indexOf(getItem(position));
//        }
//
//        @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
//        @Override
//        public View getView(final int position, View convertView, ViewGroup parent) {
//
//            if(convertView == null){
//
//                LayoutInflater mInflater = (LayoutInflater) context
//                        .getSystemService(context.LAYOUT_INFLATER_SERVICE);
//                convertView = mInflater.inflate(R.layout.listview_bidding_list, null);
//            }
//
//        /*   int colorPos = position % colors.length;
//            convertView.setBackgroundColor(colors[colorPos]);
//*/
//            TextView txtName = (TextView)convertView.findViewById(R.id.txt_sno);
//            final CheckBox checkBox1 = (CheckBox)convertView.findViewById(R.id.img_circle_listview);
//            ImageView imgIcEdit = (ImageView)convertView.findViewById(R.id.img_ic_edit);
//            BiddingList row_pos = biddingLists.get(position);
//
//            txtName.setText(row_pos.getsNo());
//
//            imgIcEdit.setOnClickListener(new View.OnClickListener() {
//                @RequiresApi(api = Build.VERSION_CODES.N)
//                @Override
//                public void onClick(View v) {
//
//                    alertEditDialog(getContext(), position);
//                }
//            });
//
//            if (checkList.contains(row_pos)) {
//                checkBox1.setChecked(true);
//                checkBox1.setButtonDrawable(R.drawable.checked);
//
//            } else {
//                checkBox1.setButtonDrawable(R.drawable.unchecked);
//                checkBox1.setChecked(false);
//            }
//
//            convertView.setTag(row_pos);
//            checkBox1.setTag(row_pos);
//
//            return convertView;
//        }
//    }
//
//
//}