package com.nexogen.routefinder;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.Toast;

import com.kyleduo.switchbutton.SwitchButton;
import com.nexogen.routefinder.fragments.CurrentLocationFragment;
import com.nexogen.routefinder.intefaces.FragmentMessangers;

public class MainActivity extends AppCompatActivity implements FragmentMessangers {

    public FragmentTransaction fragmentTransaction;
    private Menu menu;
    private MenuItem nav_navigator, nav_address, nav_location, nav_Bookmark, nav_Settings;
    private ActionBarDrawerToggle mDrawerToggle;
    private DrawerLayout drawer;
    private android.support.v4.app.FragmentManager fragmentManager;
    //    private AppLocationService appLocationService;
    private DrawerLayout mDrawerLayout;
    private Toolbar toolbar;
    private NavigationView navigationView;
    private SwitchButton switchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        toolBarAndDrawer();
        navigationDrawer();

        changeFragment(new CurrentLocationFragment(), null, "HomeFragment", true);

    }


    private void toolBarAndDrawer() {

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);


        toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(getResources().getString(R.string.currentLocation));

//        toolbar.setTitleTextColor(Color.WHITE);
        setSupportActionBar(toolbar);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();

    }

    private void navigationDrawer() {

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        View header = navigationView.getHeaderView(0);


        switchButton = header.findViewById(R.id.sb_default);



switchButton.setTextSize(18);
switchButton.setWidth(40);
        switchButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                if (switchButton.isChecked() == b)
                    Toast.makeText(MainActivity.this, "on--" + b, Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "off--" + b, Toast.LENGTH_SHORT).show();

            }
        });


        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch (id) {
                    case R.id.nav_navigator:
//                        changeFragment(new HomeFragment(), null, "HomeFragment", true);
                        break;
                    case R.id.nav_location:
                        break;
                    case R.id.nav_address:
                        break;
                    case R.id.nav_Bookmark:
                        break;
                    case R.id.nav_Settings:
                        break;

                }
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
                return false;
            }
        });
    }

    @Override
    public void changeFragment(Fragment fragment, Bundle data, String fragmentTag, boolean addToBackStack) {
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.container, fragment, fragmentTag);
        if (data != null)
            fragment.setArguments(data);
        fragmentTransaction.addToBackStack(fragmentTag);
        fragmentTransaction.commit();

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        if (fragmentManager.getBackStackEntryCount() == 0) {
            finish();
        } else {

        }
    }
}

